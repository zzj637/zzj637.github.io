import argparse
import contextlib
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import random
import signal
import time
from dataclasses import asdict
import numpy as np
import torch
from model import GPT, GPTConfig
from optimizers import AgreementSignum, kappa_at

FIELDS = ['step', 'train_loss', 'val_loss', 'val_ppl', 'lr', 'kappa',
          'agree', 'disagree', 'neutral', 'mean_gain', 'train_seconds',
          'wall_seconds', 'tokens_seen', 'peak_gb']


def atomic_json(path, value):
    tmp = path.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')
    tmp.replace(path)


def learning_rate(step, steps, peak, warmup, min_ratio):
    if step < warmup:
        return peak * (step + 1) / warmup
    progress = (step - warmup) / max(steps - warmup - 1, 1)
    return peak * (min_ratio + (1 - min_ratio) * 0.5 * (1 + math.cos(math.pi * progress)))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--optimizer', choices=['signum', 'agreement_linear', 'agreement_exp'], default='signum')
    p.add_argument('--data', default='data/wikitext103')
    p.add_argument('--out', required=True)
    p.add_argument('--lr', type=float, default=3e-5)
    p.add_argument('--steps', type=int, default=2000)
    p.add_argument('--batch', type=int, default=8)
    p.add_argument('--accum', type=int, default=8)
    p.add_argument('--block', type=int, default=512)
    p.add_argument('--layers', type=int, default=9)
    p.add_argument('--heads', type=int, default=8)
    p.add_argument('--embd', type=int, default=416)
    p.add_argument('--seed', type=int, default=101)
    p.add_argument('--momentum', type=float, default=0.9)
    p.add_argument('--gamma', type=float, default=0.99)
    p.add_argument('--kappa-start', type=float, default=0.5)
    p.add_argument('--kappa-end', type=float, default=0.0)
    p.add_argument('--exp-rate', type=float, default=5.0)
    p.add_argument('--weight-decay', type=float, default=0.0)
    p.add_argument('--warmup-fraction', type=float, default=0.05)
    p.add_argument('--min-lr-ratio', type=float, default=0.1)
    p.add_argument('--grad-clip', type=float, default=1.0)
    p.add_argument('--eval-every', type=int, default=100)
    p.add_argument('--eval-batches', type=int, default=20)
    p.add_argument('--log-every', type=int, default=10)
    p.add_argument('--device', choices=['cuda', 'cpu'], default='cuda')
    p.add_argument('--resume', action='store_true')
    p.add_argument('--max-seconds', type=float, default=0)
    p.add_argument('--stop-after', type=int, default=0, help='Pause after N total updates; preserves full schedule')
    p.add_argument('--cpu-threads', type=int, default=4)
    a = p.parse_args()
    if min(a.steps, a.batch, a.accum, a.block, a.layers, a.heads, a.embd,
           a.eval_every, a.eval_batches, a.log_every, a.cpu_threads) < 1:
        p.error('Counts must be positive')
    if a.lr <= 0 or not 0 <= a.warmup_fraction < 1 or not 0 <= a.min_lr_ratio <= 1:
        p.error('Invalid learning-rate schedule')
    if a.device == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable. Check your PyTorch image and nvidia-smi.')
    kappa_at(0, a.steps, a.kappa_start, a.kappa_end, 'linear', a.exp_rate)
    torch.set_num_threads(a.cpu_threads)
    torch.manual_seed(a.seed)
    np.random.seed(a.seed)
    random.seed(a.seed)
    if a.device == 'cuda':
        torch.cuda.manual_seed_all(a.seed)
    # No dropout and separately seeded data/eval sampling keep comparisons paired.
    data_dir = Path(a.data)
    meta = json.loads((data_dir / 'meta.json').read_text(encoding='utf-8'))
    if meta.get('format') != 'gpt2-uint16-v1':
        raise RuntimeError('Expected data from prepare.py with GPT-2 uint16 metadata')
    arrays = {}
    for split in ('train', 'val'):
        arrays[split] = np.memmap(data_dir / f'{split}.bin', dtype=np.uint16, mode='r')
        if len(arrays[split]) != meta['counts'][split] or len(arrays[split]) <= a.block:
            raise RuntimeError(f'Invalid or too short {split}.bin')
    config = GPTConfig(meta['vocab_size'], a.block, a.layers, a.heads, a.embd)
    model = GPT(config).to(a.device)  # FP32 weights; BF16 used only via autocast.
    count = sum(t.numel() for t in model.parameters())
    use_bf16 = a.device == 'cuda' and torch.cuda.is_bf16_supported()
    def autocast():
        return torch.autocast('cuda', dtype=torch.bfloat16) if use_bf16 else contextlib.nullcontext()
    def sync():
        if a.device == 'cuda':
            torch.cuda.synchronize()
    decay = [v for v in model.parameters() if v.ndim >= 2]
    no_decay = [v for v in model.parameters() if v.ndim < 2]
    opt = AgreementSignum([dict(params=decay, weight_decay=a.weight_decay),
                           dict(params=no_decay, weight_decay=0.0)],
                          lr=a.lr, momentum=a.momentum, gamma=a.gamma,
                          agreement=a.optimizer != 'signum')
    train_rng = torch.Generator().manual_seed(a.seed + 1000)
    def batch(split, rng):
        data = arrays[split]
        starts = torch.randint(len(data) - a.block, (a.batch,), generator=rng).tolist()
        windows = np.stack([data[i:i + a.block + 1] for i in starts]).astype(np.int64)
        tensor = torch.from_numpy(windows).to(a.device)
        return tensor[:, :-1].contiguous(), tensor[:, 1:].contiguous()
    @torch.no_grad()
    def evaluate():
        model.eval()
        rng = torch.Generator().manual_seed(9001)
        total = 0.0
        for _ in range(a.eval_batches):
            x, y = batch('val', rng)
            with autocast():
                _, loss = model(x, y)
            total += loss.item()
        model.train()
        return total / a.eval_batches
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    checkpoint_path = out / 'last.pt'
    metrics_path = out / 'metrics.csv'
    saved_config = {k: v for k, v in vars(a).items()
                    if k not in ('out', 'data', 'resume', 'max_seconds', 'stop_after')}
    saved_config.update(model=asdict(config), parameters=count, data_metadata=meta,
                        torch_version=torch.__version__, bf16=use_bf16)
    saved_config['code_sha256'] = hashlib.sha256(b''.join(
        Path(__file__).with_name(f).read_bytes() for f in ('train.py', 'model.py', 'optimizers.py'))).hexdigest()
    config_path = out / 'config.json'
    step = 0
    train_seconds = 0.0
    wall_before = 0.0
    best_val = None
    last_val = None
    if config_path.exists():
        if json.loads(config_path.read_text()) != saved_config:
            raise RuntimeError('Configuration differs from existing run. Use a new --out/tag.')
        if not a.resume:
            raise RuntimeError('Run exists. Use --resume or a new --out.')
        if not checkpoint_path.exists():
            raise RuntimeError('No last.pt found. Use a new output directory.')
        ck = torch.load(checkpoint_path, map_location=a.device, weights_only=False)
        model.load_state_dict(ck['model'])
        opt.load_state_dict(ck['optimizer'])
        train_rng.set_state(ck['train_rng'].cpu())
        torch.set_rng_state(ck['torch_rng'].cpu())
        if a.device == 'cuda':
            torch.cuda.set_rng_state_all([s.cpu() for s in ck['cuda_rng']])
        step, train_seconds, wall_before = ck['step'], ck['train_seconds'], ck['wall_seconds']
        best_val, last_val = ck['best_val'], ck['last_val']
        # Discard log rows newer than the last committed checkpoint after a crash.
        rows = list(csv.DictReader(metrics_path.open())) if metrics_path.exists() else []
        with metrics_path.open('w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=FIELDS); w.writeheader()
            w.writerows(r for r in rows if int(r['step']) <= step)
        print(f'Resuming at update {step}/{a.steps}', flush=True)
    else:
        atomic_json(config_path, saved_config)
        with metrics_path.open('w', newline='') as f:
            csv.DictWriter(f, fieldnames=FIELDS).writeheader()
    launch = time.monotonic()
    tokens_per_step = a.batch * a.accum * a.block
    def peak_gb():
        return torch.cuda.max_memory_allocated() / 2**30 if a.device == 'cuda' else 0.0
    def save():
        sync()
        payload = dict(model=model.state_dict(), optimizer=opt.state_dict(),
                       step=step, train_seconds=train_seconds,
                       wall_seconds=wall_before + time.monotonic() - launch,
                       best_val=best_val, last_val=last_val,
                       train_rng=train_rng.get_state(), torch_rng=torch.get_rng_state(),
                       cuda_rng=torch.cuda.get_rng_state_all() if a.device == 'cuda' else [])
        tmp = checkpoint_path.with_suffix('.pt.tmp')
        torch.save(payload, tmp); tmp.replace(checkpoint_path)
    def record(train_loss, val_loss, lr, kappa, diagnostic):
        row = dict(step=step, train_loss=train_loss, val_loss=val_loss,
                   val_ppl=math.exp(min(val_loss, 80)) if val_loss is not None else None,
                   lr=lr, kappa=kappa, train_seconds=train_seconds,
                   wall_seconds=wall_before + time.monotonic() - launch,
                   tokens_seen=step * tokens_per_step, peak_gb=peak_gb(), **diagnostic)
        with metrics_path.open('a', newline='') as f:
            csv.DictWriter(f, fieldnames=FIELDS).writerow(row)
        print(json.dumps(row), flush=True)
    stopping = [False]
    def request_stop(*_):
        stopping[0] = True
        print('Stop requested: finishing current update, then checkpointing.', flush=True)
    signal.signal(signal.SIGINT, request_stop)
    signal.signal(signal.SIGTERM, request_stop)
    print(f'{count:,} parameters; {tokens_per_step:,} tokens/update; BF16={use_bf16}', flush=True)
    if step == 0 and not a.resume:
        last_val = best_val = evaluate()
        record(None, last_val, 0.0, 0.0, {})
        save()
    warmup = int(a.steps * a.warmup_fraction)
    while step < a.steps:
        if stopping[0] or (a.max_seconds > 0 and time.monotonic() - launch >= a.max_seconds):
            break
        sync(); start = time.monotonic()
        lr = learning_rate(step, a.steps, a.lr, warmup, a.min_lr_ratio)
        kappa = 0.0 if a.optimizer == 'signum' else kappa_at(
            step, a.steps, a.kappa_start, a.kappa_end,
            'linear' if a.optimizer == 'agreement_linear' else 'exponential', a.exp_rate)
        for group in opt.param_groups:
            group['lr'] = lr
        opt.zero_grad(set_to_none=True)
        loss_sum = torch.zeros((), device=a.device)
        for _ in range(a.accum):
            x, y = batch('train', train_rng)
            with autocast():
                _, loss = model(x, y)
            loss_sum += loss.detach() / a.accum
            (loss / a.accum).backward()
        if a.grad_clip > 0:
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), a.grad_clip, error_if_nonfinite=True)
        if not torch.isfinite(loss_sum):
            raise RuntimeError('Non-finite loss; this run is not a successful comparison')
        log_now = (step + 1) % a.log_every == 0 or (step + 1) % a.eval_every == 0 or step + 1 == a.steps
        opt.step(kappa=kappa, diagnostics=log_now)
        sync(); train_seconds += time.monotonic() - start
        step += 1
        val = None
        eval_now = step % a.eval_every == 0 or step == a.steps
        if eval_now:
            val = last_val = evaluate()
            best_val = min(best_val, val)
        if log_now:
            record(loss_sum.item(), val, lr, kappa, opt.last_diagnostics)
        if eval_now:
            save()
        if a.stop_after and step >= a.stop_after:
            break
    save()
    completed = step == a.steps
    summary = dict(status='completed' if completed else 'paused', optimizer=a.optimizer,
                   lr=a.lr, seed=a.seed, steps_completed=step, steps_planned=a.steps,
                   parameters=count, tokens_per_step=tokens_per_step,
                   final_val_loss=last_val if completed else None, best_val_loss=best_val,
                   train_seconds=train_seconds, wall_seconds=wall_before + time.monotonic() - launch,
                   peak_gb=peak_gb())
    atomic_json(out / 'summary.json', summary)
    print(json.dumps(summary, indent=2), flush=True)
    return 0 if completed else 2


if __name__ == '__main__':
    raise SystemExit(main())
