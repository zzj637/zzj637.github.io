import copy
import unittest
import torch
from model import GPT, GPTConfig
from optimizers import AgreementSignum, kappa_at
from train import learning_rate


class OptimizerTests(unittest.TestCase):
    def test_signum_reference(self):
        p = torch.nn.Parameter(torch.tensor([1., -2., 0.]))
        opt = AgreementSignum([p], lr=.1, momentum=.8)
        ref = p.detach().clone(); u = torch.zeros_like(ref)
        for g in [torch.tensor([2., -3., 0.]), torch.tensor([-1., 5., 0.])]:
            p.grad = g; opt.step()
            u = .8 * u + .2 * g
            ref = ref - .1 * u.sign()
            torch.testing.assert_close(p, ref)

    def test_kappa_zero_exact_baseline_with_decay(self):
        for wd in (0., .1):
            p = torch.nn.Parameter(torch.tensor([1., -2., 0.]))
            q = torch.nn.Parameter(p.detach().clone())
            baseline = AgreementSignum([p], lr=.1, weight_decay=wd)
            variant = AgreementSignum([q], lr=.1, weight_decay=wd, agreement=True)
            for i in range(8):
                g = torch.tensor([(-1.) ** i, 2., 0.])
                p.grad = g.clone(); q.grad = g.clone()
                baseline.step(); variant.step(kappa=0.)
                torch.testing.assert_close(p, q, rtol=0, atol=0)

    def test_gain_and_history_order(self):
        p = torch.nn.Parameter(torch.zeros(2))
        opt = AgreementSignum([p], lr=.1, momentum=0, gamma=.5, agreement=True)
        p.grad = torch.tensor([1., 1.]); opt.step(kappa=.5)
        torch.testing.assert_close(p, torch.tensor([-.1, -.1]))  # zero history: no gain
        p.grad = torch.tensor([1., -1.]); opt.step(kappa=.5, diagnostics=True)
        torch.testing.assert_close(p, torch.tensor([-.25, -.05]))  # agree 1.5 / disagree 0.5
        self.assertEqual(opt.last_diagnostics['agree'], .5)
        self.assertEqual(opt.last_diagnostics['disagree'], .5)

    def test_actual_displacement_includes_decay(self):
        p = torch.nn.Parameter(torch.tensor([2.]))
        opt = AgreementSignum([p], lr=.1, gamma=.5, weight_decay=.2, agreement=True)
        old = p.detach().clone(); p.grad = torch.ones_like(p); opt.step(kappa=.5)
        torch.testing.assert_close(opt.state[p]['trajectory'], .5 * (p - old))

    def test_momentum_sign_not_raw_gradient_sign(self):
        p = torch.nn.Parameter(torch.zeros(1))
        opt = AgreementSignum([p], lr=.1, momentum=.9, agreement=True)
        p.grad = torch.tensor([100.]); opt.step()
        old = p.item(); p.grad = torch.tensor([-1.]); opt.step(kappa=.5)
        self.assertLess(p.item(), old)  # current gradient reversed; Signum momentum has not

    def test_state_roundtrip(self):
        p = torch.nn.Parameter(torch.zeros(2))
        opt = AgreementSignum([p], agreement=True)
        p.grad = torch.ones_like(p); opt.step(kappa=.5)
        q = torch.nn.Parameter(p.detach().clone()); other = AgreementSignum([q], agreement=True)
        other.load_state_dict(copy.deepcopy(opt.state_dict()))
        p.grad = q.grad = torch.tensor([-2., 3.])
        opt.step(kappa=.3); other.step(kappa=.3)
        torch.testing.assert_close(p, q, rtol=0, atol=0)

    def test_schedules(self):
        for schedule in ('linear', 'exponential'):
            v = [kappa_at(t, 100, .5, 0, schedule, 5) for t in range(100)]
            self.assertAlmostEqual(v[0], .5); self.assertAlmostEqual(v[-1], 0)
            self.assertTrue(all(0 <= x < 1 for x in v))
            self.assertTrue(all(x >= y for x, y in zip(v, v[1:])))
        self.assertLess(kappa_at(50, 100, schedule='exponential'), kappa_at(50, 100))
        self.assertAlmostEqual(kappa_at(50, 100, schedule='exponential', rate=1e-10),
                               kappa_at(50, 100), places=8)
        self.assertAlmostEqual(learning_rate(0, 100, 1, 5, .1), .2)
        self.assertAlmostEqual(learning_rate(99, 100, 1, 5, .1), .1)

    def test_model_parameter_count_and_tying(self):
        model = GPT(GPTConfig())
        count = sum(p.numel() for p in model.parameters())
        self.assertTrue(39_000_000 < count < 41_000_000, count)
        self.assertIs(model.wte.weight, model.lm_head.weight)

    def test_causal_attention_and_backward(self):
        model = GPT(GPTConfig(vocab_size=32, block_size=8, n_layer=2, n_head=2, n_embd=16))
        x = torch.randint(32, (2, 8)); changed = x.clone(); changed[:, 4:] = 0
        model.eval()
        a, loss = model(x, x); b, _ = model(changed)
        torch.testing.assert_close(a[:, :4], b[:, :4])
        loss.backward()
        self.assertTrue(all(torch.isfinite(p.grad).all() for p in model.parameters()))


if __name__ == '__main__':
    torch.set_num_threads(2)
    unittest.main(verbosity=2)
