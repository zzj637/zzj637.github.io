#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export HF_HOME="${HF_HOME:-$PWD/data/.cache/huggingface}"
export TIKTOKEN_CACHE_DIR="${TIKTOKEN_CACHE_DIR:-$PWD/data/.cache/tiktoken}"
# To use the third-party mirror, run: export HF_ENDPOINT=https://hf-mirror.com
.venv/bin/python -u prepare.py "$@"
