#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OMP_NUM_THREADS=4
export MKL_NUM_THREADS=4
PYTHON_BIN="${PYTHON_BIN:-python}"
"$PYTHON_BIN" -c 'import torch; print("Existing PyTorch:",torch.__version__); assert int(torch.__version__.split(".")[0]) >= 2; assert torch.cuda.is_available(), "Use a CUDA-enabled PyTorch AutoDL image"'
# Reuse the image's working CUDA PyTorch. Do not replace it with a CPU wheel.
"$PYTHON_BIN" -m venv --system-site-packages .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python tests.py
.venv/bin/python -c 'from model import GPT,GPTConfig; m=GPT(GPTConfig()); print("Parameters:",sum(p.numel() for p in m.parameters()))'
.venv/bin/python -m pip freeze > installed_versions.txt
.venv/bin/python - <<'PY' > runtime.json
import json
import platform

import torch

print(json.dumps({
    "python": platform.python_version(),
    "platform": platform.platform(),
    "pytorch": torch.__version__,
    "cuda": torch.version.cuda,
    "cudnn": torch.backends.cudnn.version(),
    "gpu": torch.cuda.get_device_name(0),
    "bf16_supported": torch.cuda.is_bf16_supported(),
}, indent=2))
PY
echo 'Installation and optimizer tests completed.'
