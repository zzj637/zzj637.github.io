"""GPT-2 BPE uint16 data preparation; bounded streaming download, validation only."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import numpy as np


DATASET_ID = 'Salesforce/wikitext'
DATASET_CONFIG = 'wikitext-103-raw-v1'
DATASET_REVISION = 'b08601e04326c79dfdd32d625aee71d232d685c3'


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--out', default='data/wikitext103')
    p.add_argument('--train-tokens', type=int, default=100_000_000)
    p.add_argument('--val-tokens', type=int, default=1_000_000)
    p.add_argument('--revision', default=DATASET_REVISION)
    p.add_argument('--train-text', help='Optional local UTF-8 training file')
    p.add_argument('--val-text', help='Separate local UTF-8 validation file')
    a = p.parse_args()
    if min(a.train_tokens, a.val_tokens) < 2:
        p.error('Token limits must be >= 2')
    if bool(a.train_text) != bool(a.val_text):
        p.error('Provide both train-text and val-text')
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    meta_path = out / 'meta.json'
    token_limits = {'train': a.train_tokens, 'val': a.val_tokens}
    if meta_path.exists():
        print('Existing completed data found; checking hashes (no overwrite).')
        meta = json.loads(meta_path.read_text(encoding='utf-8'))
        if meta.get('token_limits', token_limits) != token_limits:
            raise RuntimeError('Token limits differ from existing data; use a new --out directory')
        if not a.train_text and len(a.revision) == 40 and (
            meta.get('source') != f'{DATASET_ID}/{DATASET_CONFIG}'
            or meta.get('revision') != a.revision
        ):
            raise RuntimeError('Dataset revision differs from existing data; use a new --out directory')
        for split in ('train', 'val'):
            path = out / f'{split}.bin'
            if digest(path) != meta['sha256'][split]:
                raise RuntimeError(f'{split} data hash mismatch')
        print(meta)
        return
    import tiktoken
    enc = tiktoken.get_encoding('gpt2')
    if a.train_text:
        def records(split):
            with open(a.train_text if split == 'train' else a.val_text, encoding='utf-8') as f:
                for line in f:
                    yield {'text': line}
        revision = None
        source = {'train': str(Path(a.train_text).resolve()), 'val': str(Path(a.val_text).resolve())}
    else:
        from huggingface_hub import HfApi
        from datasets import load_dataset
        revision = HfApi().dataset_info(DATASET_ID, revision=a.revision, timeout=60).sha
        def records(split):
            return load_dataset(DATASET_ID, DATASET_CONFIG,
                                split='train' if split == 'train' else 'validation',
                                revision=revision, streaming=True)
        source = f'{DATASET_ID}/{DATASET_CONFIG}'
    meta = dict(format='gpt2-uint16-v1', tokenizer='gpt2', vocab_size=50257,
                source=source, revision=revision, token_limits=token_limits,
                counts={}, sha256={},
                endpoint=os.environ.get('HF_ENDPOINT', 'https://huggingface.co'))
    for split, limit in [('train', a.train_tokens), ('val', a.val_tokens)]:
        target = out / f'{split}.bin'
        if target.exists():
            raise RuntimeError(f'{target} exists without completed metadata; use a new --out directory')
        tmp = target.with_suffix('.bin.partial')
        count = 0
        next_print = 5_000_000
        with open(tmp, 'wb') as f:
            for item in records(split):
                if not item['text'].strip():
                    continue
                ids = enc.encode_ordinary(item['text']) + [enc.eot_token]
                ids = ids[:limit - count]
                np.asarray(ids, dtype=np.uint16).tofile(f)
                count += len(ids)
                if count >= next_print:
                    print(f'{split}: {count:,} tokens', flush=True)
                    next_print += 5_000_000
                if count >= limit:
                    break
        if count < 2:
            raise RuntimeError(f'Empty {split} data')
        tmp.replace(target)
        meta['counts'][split] = count
        meta['sha256'][split] = digest(target)
        print(f'{split}: completed {count:,} tokens', flush=True)
    meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding='utf-8')


if __name__ == '__main__':
    main()
