# Local correctness checks

- 9 optimizer/model/schedule unit tests: PASS.
- Signum, agreement_linear, agreement_exp: CPU tiny-model synthetic-data training: PASS.
- Paused/resumed training vs uninterrupted training: exact FP32 model equality: PASS (CPU).
- Sequential sweep and skipping completed runs: PASS.
- CSV aggregation and plot generation: PASS.
- Default 40M architecture instantiated and parameter tying checked: PASS.
- Test environment: Windows, Python 3.12.14, PyTorch 2.14.1+cpu, NumPy 2.5.3, Matplotlib 3.11.2.
- Release shell syntax and dataset cache checks (revision, requested limits, hashes): PASS.
- Full 40M GPU training: NOT RUN locally.
- Hugging Face real-data preparation: NOT RUN locally.
- Synthetic-data checks verify execution only; they provide NO performance evidence.

Re-run optimizer tests: `.venv/bin/python tests.py`
Optional full CPU pipeline check: `.venv/bin/python test_pipeline.py`
