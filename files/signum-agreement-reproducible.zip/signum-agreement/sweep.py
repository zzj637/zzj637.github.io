"""Sequential, resumable runs. Never silently ignore a failed run."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--tag', default='pilot')
    p.add_argument('--lrs', type=float, nargs='+', default=[1e-5, 3e-5, 1e-4])
    p.add_argument('--seeds', type=int, nargs='+', default=[101])
    p.add_argument('--optimizers', nargs='+', default=['signum', 'agreement_linear', 'agreement_exp'],
                   choices=['signum', 'agreement_linear', 'agreement_exp'])
    p.add_argument('--steps', type=int, default=2000)
    p.add_argument('--max-hours', type=float, default=0, help='Soft wall-time limit; 0 means unlimited')
    a, extra = p.parse_known_args()
    root = Path(__file__).resolve().parent
    if not a.tag or Path(a.tag).name != a.tag or a.tag in ('.', '..'):
        p.error('tag must be a simple directory name')
    folder = root / 'runs' / a.tag
    folder.mkdir(parents=True, exist_ok=True)
    data_arg = extra[extra.index('--data') + 1] if '--data' in extra else 'data/wikitext103'
    data_path = Path(data_arg)
    if not data_path.is_absolute():
        data_path = root / data_path
    data_metadata = json.loads((data_path / 'meta.json').read_text(encoding='utf-8'))
    code_hash = hashlib.sha256(b''.join((root / f).read_bytes()
                                     for f in ('train.py', 'model.py', 'optimizers.py'))).hexdigest()
    protocol = dict(steps=a.steps, lrs=a.lrs, seeds=a.seeds, optimizers=a.optimizers,
                    extra=extra, data_metadata=data_metadata, code_sha256=code_hash)
    protocol_path = folder / 'protocol.json'
    if protocol_path.exists() and json.loads(protocol_path.read_text()) != protocol:
        raise RuntimeError('Protocol changed. Choose a NEW --tag instead of mixing experiments.')
    protocol_path.write_text(json.dumps(protocol, indent=2))
    start = time.monotonic()
    for seed in a.seeds:
        for lr in a.lrs:
            for optimizer in a.optimizers:
                name = f'{optimizer}_lr{lr:g}_seed{seed}'
                out = folder / name
                summary = out / 'summary.json'
                if summary.exists() and json.loads(summary.read_text()).get('status') == 'completed':
                    print(f'Skipping completed: {name}', flush=True)
                    continue
                remaining = a.max_hours * 3600 - (time.monotonic() - start)
                if a.max_hours > 0 and remaining <= 0:
                    print('Time limit reached. Repeat the same command to continue.', flush=True)
                    return
                command = [sys.executable, '-u', str(root / 'train.py'), '--optimizer', optimizer,
                           '--lr', str(lr), '--seed', str(seed), '--steps', str(a.steps),
                           '--out', str(out)] + extra
                if (out / 'last.pt').exists():
                    command.append('--resume')
                if a.max_hours > 0:
                    command += ['--max-seconds', str(max(1, remaining))]
                print('Running:', ' '.join(command), flush=True)
                print(f'Log: {folder / (name + ".log")}', flush=True)
                with (folder / (name + '.log')).open('a', encoding='utf-8') as log:
                    result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
                if result.returncode == 2:
                    print('Run paused with checkpoint. Repeat the SAME command to continue.', flush=True)
                    return
                if result.returncode:
                    raise SystemExit(f'{name} failed ({result.returncode}); inspect its .log. Sweep stopped.')
                print(summary.read_text(), flush=True)
    subprocess.run([sys.executable, str(root / 'summarize.py'), str(folder)], check=True)


if __name__ == '__main__':
    main()
