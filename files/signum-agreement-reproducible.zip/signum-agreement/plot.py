import argparse
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import json


def main():
    p = argparse.ArgumentParser()
    p.add_argument('folder', nargs='?', default='runs/pilot')
    p.add_argument('--from-step', type=int, default=0)
    p.add_argument('--to-step', type=int, default=0)
    p.add_argument('--tick', type=float, default=0, help='Optional y-axis tick spacing')
    a = p.parse_args()
    root = Path(a.folder)
    groups = {}
    for path in sorted(root.glob('*/metrics.csv')):
        config = json.loads((path.parent / 'config.json').read_text())
        rows = list(csv.DictReader(path.open()))
        vals = {int(r['step']): float(r['val_loss']) for r in rows if r['val_loss'] and
                int(r['step']) >= a.from_step and (not a.to_step or int(r['step']) <= a.to_step)}
        groups.setdefault(config['lr'], []).append((config['optimizer'], config['seed'], vals))
    if not groups:
        raise SystemExit('No metrics.csv found')
    fig, axes = plt.subplots(1, len(groups), figsize=(6 * len(groups), 4.6), squeeze=False)
    colors = {'signum': '#1f77b4', 'agreement_linear': '#ff7f0e', 'agreement_exp': '#2ca02c'}
    for ax, (lr, runs) in zip(axes[0], sorted(groups.items())):
        for name in colors:
            series = [v for optimizer, _, v in runs if optimizer == name and v]
            if not series:
                continue
            # Do not silently average partially completed runs over different seed sets.
            steps = sorted(set.intersection(*(set(v) for v in series)))
            if not steps:
                continue
            values = np.asarray([[v[s] for s in steps] for v in series])
            mean = values.mean(axis=0)
            ax.plot(steps, mean, label=f'{name} (n={len(series)})', color=colors[name])
            if len(series) > 1:
                sd = values.std(axis=0, ddof=1)
                ax.fill_between(steps, mean - sd, mean + sd, alpha=.15, color=colors[name])
        ax.set(title=f'LR = {lr:g}', xlabel='Optimizer updates', ylabel='Validation loss')
        ax.grid(alpha=.25); ax.legend(fontsize=8)
        if a.tick > 0:
            from matplotlib.ticker import MultipleLocator
            ax.yaxis.set_major_locator(MultipleLocator(a.tick))
    fig.tight_layout()
    dest = root / f'validation_loss_{a.from_step}_{a.to_step or "end"}.png'
    fig.savefig(dest, dpi=180); plt.close(fig)
    print(dest)
    # Show BOTH LR and kappa, which are separate schedules.
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    first_lr = sorted(groups)[0]
    seen = set()
    for optimizer, seed, _ in groups[first_lr]:
        if optimizer in seen:
            continue
        seen.add(optimizer)
        path = root / f'{optimizer}_lr{first_lr:g}_seed{seed}' / 'metrics.csv'
        rows = [r for r in csv.DictReader(path.open()) if int(r['step']) > 0]
        for ax, field in zip(axes, ['lr', 'kappa']):
            ax.plot([int(r['step']) for r in rows], [float(r[field]) for r in rows], label=optimizer)
            ax.set(xlabel='Optimizer updates', ylabel=field); ax.grid(alpha=.25); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(root / 'schedules.png', dpi=180); plt.close(fig)


if __name__ == '__main__':
    main()
