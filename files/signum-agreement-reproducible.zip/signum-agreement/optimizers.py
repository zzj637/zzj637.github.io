"""Signum and trajectory-agreement Signum. All model parameters use this optimizer."""
import math
import torch


def kappa_at(step, total_steps, start=0.5, end=0.0, schedule='linear', rate=5.0):
    """0-based update index. Both schedules have the SAME start and end values.

    Exponential is a shifted/normalized exponential, not a pure exp(-rate*p).
    """
    if total_steps < 1 or not 0 <= step < total_steps:
        raise ValueError('Invalid step or total_steps')
    if not (0 <= end <= start < 1) or not math.isfinite(rate) or rate <= 0:
        raise ValueError('Require 0 <= kappa_end <= kappa_start < 1 and rate > 0')
    progress = step / max(total_steps - 1, 1)
    if schedule == 'linear':
        factor = 1 - progress
    elif schedule == 'exponential':
        factor = math.exp(-rate * progress) * (-math.expm1(-rate * (1 - progress))) / (-math.expm1(-rate))
    else:
        raise ValueError(f'Unknown schedule {schedule}')
    return end + (start - end) * max(0.0, factor)


class AgreementSignum(torch.optim.Optimizer):
    def __init__(self, params, lr=1e-4, momentum=0.9, gamma=0.99,
                 weight_decay=0.0, agreement=False):
        if lr < 0 or weight_decay < 0 or not 0 <= momentum < 1 or not 0 <= gamma < 1:
            raise ValueError('Invalid optimizer hyperparameters')
        super().__init__(params, dict(lr=lr, momentum=momentum, gamma=gamma,
                                     weight_decay=weight_decay, agreement=agreement))

    @torch.no_grad()
    def step(self, closure=None, *, kappa=0.0, diagnostics=False):
        if not 0 <= kappa < 1:
            raise ValueError('kappa must be in [0,1)')
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()
        counts = None
        total = 0
        for group in self.param_groups:
            for p in group['params']:
                if p.grad is None:
                    continue
                if p.grad.is_sparse:
                    raise RuntimeError('Sparse gradients unsupported')
                if p.dtype != torch.float32:
                    raise RuntimeError('Use FP32 master parameters (BF16 autocast is supported)')
                state = self.state[p]
                if not state:
                    state['momentum'] = torch.zeros_like(p)
                    if group['agreement']:
                        state['trajectory'] = torch.zeros_like(p)
                u = state['momentum']
                u.mul_(group['momentum']).add_(p.grad, alpha=1 - group['momentum'])
                direction = -u.sign()   # Signum direction, NOT -sign(raw_gradient).
                if group['agreement']:
                    m = state['trajectory']
                    product = m.sign() * direction  # history BEFORE this update
                    gain = 1 + kappa * product
                    if diagnostics:
                        local = torch.stack(((product > 0).sum(), (product < 0).sum(),
                                             (product == 0).sum())).to(torch.float64)
                        counts = local if counts is None else counts + local
                        total += p.numel()
                    old = p.clone()
                    p.mul_(1 - group['lr'] * group['weight_decay'])
                    p.add_(gain * direction, alpha=group['lr'])
                    # Full ACTUAL displacement, including decoupled weight decay.
                    displacement = p - old
                    m.mul_(group['gamma']).add_(displacement, alpha=1 - group['gamma'])
                else:
                    p.mul_(1 - group['lr'] * group['weight_decay'])
                    p.add_(direction, alpha=group['lr'])
        self.last_diagnostics = {}
        if counts is not None:
            fractions = (counts / total).cpu().tolist()
            self.last_diagnostics = dict(zip(('agree', 'disagree', 'neutral'), fractions))
            self.last_diagnostics['mean_gain'] = 1 + kappa * (fractions[0] - fractions[1])
        return loss
