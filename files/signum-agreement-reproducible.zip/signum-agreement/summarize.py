import argparse
import csv
import json
from pathlib import Path
import statistics


def main():
    p = argparse.ArgumentParser()
    p.add_argument('folder', nargs='?', default='runs/pilot')
    a = p.parse_args()
    root = Path(a.folder)
    rows = []
    groups = {}
    for path in sorted(root.glob('*/summary.json')):
        row = json.loads(path.read_text())
        row['run'] = path.parent.name
        rows.append(row)
        print(f"{row['run']}: {row['status']}, final_val_loss={row['final_val_loss']}")
        if row['status'] == 'completed':
            groups.setdefault((row['optimizer'], row['lr']), []).append(row['final_val_loss'])
    if not rows:
        print('No summaries yet. Inspect the run .log files.')
        return
    with (root / 'summary.csv').open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print('\nFinal validation loss by optimizer and LR (same training horizon):')
    for (optimizer, lr), values in sorted(groups.items()):
        std = statistics.stdev(values) if len(values) > 1 else None
        print(f'{optimizer:20} lr={lr:g}, n={len(values)}, mean={statistics.mean(values):.6f}, std={std}')
    print('Select LR per method on validation; then confirm on multiple paired seeds. No universal superiority claim.')


if __name__ == '__main__':
    main()
