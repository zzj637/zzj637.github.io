# 在 AutoDL 上运行 Signum 对照实验

## 实验设置

实验从零训练仓库自带的 nanoGPT 风格语言模型。模型有 9 层、8 个注意力头，隐藏维度为 416，序列长度为 512，GPT-2 BPE 词表大小为 50257。输入和输出共享嵌入权重，模型共有 **39,825,760 个参数（约 39.83M）**。

三种方法使用相同的模型、数据、基础学习率调度、梯度裁剪和验证样本。

1. `signum` 对梯度做平滑，再取符号。
2. `agreement_linear` 用轨迹一致性调节 Signum 的步长，κ 线性衰减。
3. `agreement_exp` 使用同样的步长调节规则，κ 按指数曲线衰减。

选定的 Signum 方法更新全部可训练参数，包括嵌入和输出层。LayerNorm 参数的权重衰减为零，其余参数使用设定的解耦权重衰减。实验默认将权重衰减设为零，单独考察步长调节的效果。

## 更新式

`u` 是梯度动量，`m` 是实际参数位移的 EMA。每步先用更新前的 `m` 计算步长系数。

```text
u_t = b * u_(t-1) + (1-b) * g_t
r_t = -sign(u_t)                        # Signum 下降方向
s_t = sign(m_t)
gain_t = 1 + kappa_t * (s_t * r_t)       # 按坐标，一致大步，不一致小步
x_(t+1) = (1 - lr_t * wd) * x_t + lr_t * gain_t * r_t
m_(t+1) = gamma * m_t + (1-gamma) * (x_(t+1)-x_t)
```

Signum 基线用 `gain=1`，只维护梯度动量。实验实现的更新方向是 `r=-sign(u)`。最初的 Idea 2 公式用 `r=-sign(g)`。梯度在当前参数处计算。`u` 和 `m` 从零开始，`sign(0)=0`，所以首步 `gain=1`。κ=0 时，变体与基线的参数更新完全相同。对 `u` 做正数倍的偏差修正会保留其符号，代码直接取 `u` 的符号。

启用权重衰减时，`m` 也记录衰减产生的位移。比较优化器时，各组使用相同的权重衰减设置。

## 两种 κ 衰减

更新索引为 `t=0,...,T-1`，进度为 `p=t/max(T-1,1)`。κ0 和 κf 分别是起点和终点。

```text
线性：κ_t = κf + (κ0-κf)*(1-p)
指数：κ_t = κf + (κ0-κf)*(exp(-a*p)-exp(-a))/(1-exp(-a))
```

默认 κ0=0.5、κf=0、a=5。指数曲线经过平移和归一化，与线性曲线一样从 0.5 降到 0。指数曲线前期降得更快，中段 κ 更小。两种方案的累计 κ 也不同，比较结果同时反映曲线形状和累计调节强度。

基础学习率有独立的日程。前 5% 线性预热，随后余弦衰减至峰值的 10%。`schedules.png` 同时展示学习率和 κ。

## 第一步　上传和解压

实验用一张 GPU，选择带 CUDA PyTorch 2.x 的镜像即可。使用原始 ZIP 时，先上传到 `/root/autodl-tmp`，再执行下面的命令。直接上传仓库文件夹时，进入实际目录运行安装脚本，后续命令也使用该目录。

```bash
cd /root/autodl-tmp
unzip autodl_signum_agreement_40m.zip
cd /root/autodl-tmp/autodl_signum_agreement_40m
bash 00_install.sh
```

安装脚本用当前 Python 创建 `.venv`，复用镜像自带的 CUDA PyTorch。如果解释器叫 `python3`，可用下面的命令指定。

```bash
PYTHON_BIN=python3 bash 00_install.sh
```

安装脚本会运行单元测试并打印模型参数量。测试通过后开始准备数据。

## 第二步　准备数据

数据准备使用 WikiText-103 的训练集与验证集，按 GPT-2 BPE 编码为 `uint16`。训练集上限是 100M token，验证集上限是 1M token，较短的划分按实际长度保留。`meta.json` 记录数据版本、token 数和 SHA-256。每份数据准备一次即可。

```bash
bash 01_prepare.sh
```

Hugging Face 直连失败时，可在同一个终端指定第三方镜像。

```bash
export HF_ENDPOINT=https://hf-mirror.com
bash 01_prepare.sh
```

GPT-2 tokenizer 首次运行还要下载编码表。编码表下载失败时，可以在联网电脑上准备好整个 `data` 目录再上传。数据和模型使用同一套 GPT-2 词表。

网络中断后，如果已有完整的 `meta.json`，重跑会校验哈希并复用数据。如果目录里只留下了 `.bin` 文件，请用新目录重新准备，训练时通过 `--data` 指定该目录。

```bash
bash 01_prepare.sh --out data/wikitext103_retry
# 之后所有训练都加：--data data/wikitext103_retry
```

使用本地 UTF-8 文本时，分别提供训练和验证文件。

```bash
bash 01_prepare.sh --out data/mytext --train-text /path/train.txt --val-text /path/val.txt
```

复用已有数据时，确认编码为 GPT-2 BPE、类型为 `uint16`，并包含脚本生成的 `meta.json`。随机合成数据用于检查训练流程。

## 第三步　试跑 100 步

试跑检查三种方法的训练流程、损失值、日志和断点恢复。

```bash
tmux new -s signum40
cd /root/autodl-tmp/autodl_signum_agreement_40m
bash 02_smoke.sh
```

默认 `batch=8`、`accum=8`、`block=512`。单张 GPU 每次更新处理 32768 个 token，100 步约处理 3.28M 个训练 token。显存不足时，用新 tag 减小微批、增加梯度累积次数，保持有效批大小。

```bash
.venv/bin/python -u sweep.py --tag smoke_b4 --steps 100 --lrs 0.00003 --seeds 101 \
  --batch 4 --accum 16 --eval-every 50 --eval-batches 5
```

改变批大小会影响验证采样的分组。正式比较时，三个方法使用相同的配置和新的 tag。

先按 Ctrl+B，松开后再按 D，即可离开 tmux 界面并让训练继续运行。用下面的命令重新进入会话。

```bash
tmux attach -t signum40
```

训练全部结束后，tmux 会话和 AutoDL 实例可能仍在运行。在日志监控终端按 Ctrl+C 可退出监控。在训练终端按 Ctrl+C 会请求暂停并保存检查点。

## 第四步　初筛 3 个学习率 × 3 种方法

```bash
bash 03_pilot.sh
```

默认学习率为 1e-5、3e-5、1e-4，每组用种子 101 跑 2000 步，共 9 次顺序训练。每次约处理 65.54M 个训练 token，随机抽取的窗口可能重叠。这轮实验用来选出候选学习率。

用下面的命令设置本次运行的时限。

```bash
bash 03_pilot.sh --max-hours 1
```

这是训练的软时限。脚本在一次更新结束后保存检查点，当前更新、评估和保存可能略超时。实例关机时间可在 AutoDL 单独设置。

## 实时看日志

在另一个终端运行日志监控。

```bash
cd /root/autodl-tmp/autodl_signum_agreement_40m
bash 05_watch.sh pilot
```

监控会显示启动时已有的日志。下一组创建日志后，重新运行即可加入新日志。也可以单独查看某组日志。

```bash
tail -f runs/pilot/agreement_linear_lr3e-05_seed101.log
```

日志文件名里的学习率使用 Python 的 `:g` 格式，例如 `1e-05`、`3e-05` 和 `0.0001`。

每 10 步记录一次训练损失，每 100 步记录一次验证损失。训练损失取当前更新中各微批的均值。三个方法每次评估都使用同一组固定窗口。

## 第五步　汇总结果和绘图

```bash
bash 04_plot.sh pilot
```

- `runs/pilot/summary.csv` 汇总每次运行的最终和最低验证损失、用时与显存。
- `runs/pilot/validation_loss_0_end.png` 按学习率分为三张子图，每张比较三种方法。
- `runs/pilot/schedules.png` 展示学习率和 κ 的实际变化。
- 每次运行目录内的 `metrics.csv` 记录训练和验证损失、学习率、κ、一致率、冲突率、中立率、平均步长系数和 token 数。
- `last.pt` 保存模型、优化器、轨迹和动量状态，以及采样随机数生成器的状态。

下面的命令绘制 1000 步之后的曲线，纵轴刻度间距为 0.01。

```bash
.venv/bin/python plot.py runs/pilot --from-step 1000 --tick 0.01
```

先看默认图的纵轴范围，再选刻度间距。范围较宽时，0.01 的间距会让刻度过密。

用**最终验证损失**比较各方法。报告同一学习率下的配对结果，以及各方法在相同学习率搜索预算下取得的较好结果。可以查看 `mean_gain`，估计轨迹调节对平均步长的影响。

## 断网或中断后怎么恢复

先检查训练进程和 tmux 会话是否还在运行。

```bash
pgrep -af 'train.py|sweep.py'
tmux ls
```

进程停止且已有检查点时，重跑**同一条** sweep 命令。脚本会跳过已完成的组，从暂停组的 `last.pt` 继续。

```bash
cd /root/autodl-tmp/autodl_signum_agreement_40m
bash 03_pilot.sh
```

更改总步数、学习率、批大小、优化器或代码时，使用新 tag。总步数决定学习率和 κ 的日程。若要把 2000 步实验改为 5000 步，用新 tag 从头运行。进程崩溃后会从最近的评估检查点恢复，默认每 100 步保存一次。正常暂停的运行会标记为 `paused`。

## 第六步　多种子对照

从初筛中选一个候选学习率，用三个配对种子比较三种方法。下面用 3e-5 举例。

```bash
.venv/bin/python -u sweep.py --tag confirm_lr3e5 --steps 5000 \
  --lrs 0.00003 --seeds 101 202 303 --eval-every 100 --eval-batches 40
bash 04_plot.sh confirm_lr3e5
```

上面的 5000 步实验从头运行。若要比较各方法自己的候选学习率，可以分别用三个 tag。

```bash
# 把每行 LR 换成该方法初筛得到的候选值。
.venv/bin/python -u sweep.py --tag confirm_signum --optimizers signum --steps 5000 --lrs 0.00003 --seeds 101 202 303 --eval-batches 40
.venv/bin/python -u sweep.py --tag confirm_linear --optimizers agreement_linear --steps 5000 --lrs 0.00003 --seeds 101 202 303 --eval-batches 40
.venv/bin/python -u sweep.py --tag confirm_exp --optimizers agreement_exp --steps 5000 --lrs 0.00003 --seeds 101 202 303 --eval-batches 40
```

用验证集调参。正式评估时，先固定实验设置，再用独立数据评价。

## 建议的消融

单元测试覆盖了 κ=0 时的更新等价性。跑训练消融时，用新 tag。

```bash
.venv/bin/python -u sweep.py --tag kappa_zero --steps 2000 --lrs 0.00003 --seeds 101 --kappa-start 0 --kappa-end 0
```

如果方向一致率长期接近一，变体的效果可能主要来自更大的有效步长。可以加一组使用较大学习率的标准 Signum，并给三个方法相同的调参预算。也可试 κ0=0.1、0.3、0.5，比较不同调节强度。

## 正确性与来源

`tests.py` 覆盖基线参考更新、κ=0 时的等价性、方向一致或冲突的坐标及中立坐标、历史更新顺序、梯度动量的符号、启用权重衰减后的实际位移、状态保存与恢复、衰减边界、模型规模和因果注意力。

Signum 的定义参考 Bernstein 等人的论文。[SignSGD](https://proceedings.mlr.press/v80/bernstein18a.html)

模型用 PyTorch 的 `scaled_dot_product_attention` 实现因果注意力。[PyTorch 文档](https://docs.pytorch.org/docs/stable/generated/torch.nn.functional.scaled_dot_product_attention.html)
