#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
tag="${1:-pilot}"
mapfile -t logs < <(find "runs/$tag" -maxdepth 1 -type f -name '*.log' | sort)
if ((${#logs[@]} == 0)); then echo "No logs under runs/$tag yet."; exit 1; fi
echo 'Ctrl+C stops watching only. Re-run this watcher when the next run starts.'
tail -n 20 -F "${logs[@]}"
