"""Local CPU integration QA. Uses SYNTHETIC data, never evidence of optimizer quality."""
import csv
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import numpy as np
import torch

root = Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='signum_qa_') as tmp:
    tmp = Path(tmp)
    data = tmp / 'data'; data.mkdir()
    rng = np.random.default_rng(123)
    for split in ['train', 'val']:
        rng.integers(0, 32, 4096, dtype=np.uint16).tofile(data / f'{split}.bin')
    meta = dict(format='gpt2-uint16-v1', vocab_size=32, tokenizer='SYNTHETIC_TEST_ONLY',
                counts=dict(train=4096, val=4096), sha256={}, fixture=True)
    (data / 'meta.json').write_text(json.dumps(meta))
    args = ['--data', str(data), '--device', 'cpu', '--steps', '4', '--batch', '2',
            '--accum', '2', '--block', '8', '--layers', '2', '--heads', '2', '--embd', '16',
            '--eval-every', '2', '--eval-batches', '2', '--log-every', '1', '--cpu-threads', '1']
    def run(out, optimizer, extra=(), expected=0):
        command = [sys.executable, str(root / 'train.py'), '--out', str(out),
                   '--optimizer', optimizer, *args, *extra]
        result = subprocess.run(command, cwd=root, capture_output=True, text=True)
        if result.returncode != expected:
            raise RuntimeError(result.stdout + result.stderr)
        return json.loads((out / 'summary.json').read_text())
    report = {}
    for name in ['signum', 'agreement_linear', 'agreement_exp']:
        out = tmp / name
        summary = run(out, name)
        assert summary['status'] == 'completed' and summary['steps_completed'] == 4
        assert len(list(csv.DictReader((out / 'metrics.csv').open()))) == 5
        report[name] = summary['final_val_loss']
    full = tmp / 'agreement_linear'
    resumed = tmp / 'resumed'
    paused = run(resumed, 'agreement_linear', ['--stop-after', '2'], expected=2)
    assert paused['status'] == 'paused' and paused['final_val_loss'] is None
    finished = run(resumed, 'agreement_linear', ['--resume'])
    x = torch.load(full / 'last.pt', weights_only=False)
    y = torch.load(resumed / 'last.pt', weights_only=False)
    for key in x['model']:
        torch.testing.assert_close(x['model'][key], y['model'][key], rtol=0, atol=0)
    assert x['last_val'] == y['last_val']
    assert torch.equal(x['train_rng'], y['train_rng'])
    assert len(list(csv.DictReader((resumed / 'metrics.csv').open()))) == 5
    # Exercise aggregation and plotting too.
    subprocess.run([sys.executable, str(root / 'summarize.py'), str(tmp)], check=True)
    # Exercise sweep execution, skip-completed behavior, and protocol consistency in a temp copy.
    import shutil
    sweep_copy = tmp / 'sweep_copy'; sweep_copy.mkdir()
    for name in ('sweep.py', 'train.py', 'model.py', 'optimizers.py', 'summarize.py'):
        shutil.copy2(root / name, sweep_copy / name)
    command = [sys.executable, str(sweep_copy / 'sweep.py'), '--tag', 'qa_fixture',
               '--lrs', '0.00003', '--seeds', '101', *args]
    subprocess.run(command, check=True)
    skipped = subprocess.run(command, check=True, capture_output=True, text=True)
    assert skipped.stdout.count('Skipping completed:') == 3
    # Direct plot smoke uses normal names without leaving a synthetic run in the ZIP.
    plotroot = tmp / 'plot'; plotroot.mkdir()
    for name in ['signum', 'agreement_linear', 'agreement_exp']:
        shutil.copytree(tmp / name, plotroot / f'{name}_lr3e-05_seed101')
    subprocess.run([sys.executable, str(root / 'plot.py'), str(plotroot)], check=True)
    assert (plotroot / 'validation_loss_0_end.png').exists()
    assert (plotroot / 'schedules.png').exists()
    report['exact_resume'] = True
    report['sweep_and_skip_completed'] = True
    report['plot_and_summary'] = True
    destination = Path(__file__).resolve().parent / 'pipeline_qa.json'
    destination.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
