#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4
.venv/bin/python -u sweep.py --tag pilot --steps 2000 --lrs 0.00001 0.00003 0.0001 --seeds 101 --eval-every 100 --eval-batches 20 "$@"
