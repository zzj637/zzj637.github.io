#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

bash 00_install.sh
bash 01_prepare.sh
bash 02_smoke.sh
bash 03_pilot.sh
bash 04_plot.sh
