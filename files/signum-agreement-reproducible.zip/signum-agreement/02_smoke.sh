#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4
.venv/bin/python -u sweep.py --tag smoke --steps 100 --lrs 0.00003 --seeds 101 --eval-every 50 --eval-batches 5 "$@"
