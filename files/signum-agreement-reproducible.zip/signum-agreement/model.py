"""Standalone nanoGPT-style decoder; no vendor/model.py download required."""
import math
from dataclasses import dataclass
import torch
from torch import nn
from torch.nn import functional as F


@dataclass
class GPTConfig:
    vocab_size: int = 50257
    block_size: int = 512
    n_layer: int = 9
    n_head: int = 8
    n_embd: int = 416
    dropout: float = 0.0


class Attention(nn.Module):
    def __init__(self, c):
        super().__init__()
        assert c.n_embd % c.n_head == 0
        self.heads = c.n_head
        self.dropout = c.dropout
        self.c_attn = nn.Linear(c.n_embd, 3 * c.n_embd, bias=False)
        self.c_proj = nn.Linear(c.n_embd, c.n_embd, bias=False)

    def forward(self, x):
        b, t, d = x.shape
        q, k, v = self.c_attn(x).split(d, dim=-1)
        q, k, v = [a.view(b, t, self.heads, d // self.heads).transpose(1, 2)
                   for a in (q, k, v)]
        y = F.scaled_dot_product_attention(q, k, v, is_causal=True,
                                          dropout_p=self.dropout if self.training else 0.0)
        return self.c_proj(y.transpose(1, 2).contiguous().view(b, t, d))


class Block(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.ln1 = nn.LayerNorm(c.n_embd)
        self.attn = Attention(c)
        self.ln2 = nn.LayerNorm(c.n_embd)
        self.mlp = nn.Sequential(nn.Linear(c.n_embd, 4 * c.n_embd, bias=False),
                                 nn.GELU(), nn.Linear(4 * c.n_embd, c.n_embd, bias=False))
        self.drop = nn.Dropout(c.dropout)

    def forward(self, x):
        x = x + self.drop(self.attn(self.ln1(x)))
        return x + self.drop(self.mlp(self.ln2(x)))


class GPT(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.config = c
        self.wte = nn.Embedding(c.vocab_size, c.n_embd)
        self.wpe = nn.Embedding(c.block_size, c.n_embd)
        self.blocks = nn.ModuleList([Block(c) for _ in range(c.n_layer)])
        self.ln_f = nn.LayerNorm(c.n_embd)
        self.lm_head = nn.Linear(c.n_embd, c.vocab_size, bias=False)
        self.lm_head.weight = self.wte.weight
        self.apply(self._init)
        for name, p in self.named_parameters():
            if name.endswith('c_proj.weight') or name.endswith('mlp.2.weight'):
                nn.init.normal_(p, std=0.02 / math.sqrt(2 * c.n_layer))

    @staticmethod
    def _init(m):
        if isinstance(m, (nn.Linear, nn.Embedding)):
            nn.init.normal_(m.weight, std=0.02)
            if getattr(m, 'bias', None) is not None:
                nn.init.zeros_(m.bias)

    def forward(self, tokens, targets=None):
        _, t = tokens.shape
        if t > self.config.block_size:
            raise ValueError('Sequence exceeds block_size')
        x = self.wte(tokens) + self.wpe(torch.arange(t, device=tokens.device))
        for block in self.blocks:
            x = block(x)
        logits = self.lm_head(self.ln_f(x))
        loss = None if targets is None else F.cross_entropy(
            logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss
