#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
.venv/bin/python summarize.py "runs/${1:-pilot}"
.venv/bin/python plot.py "runs/${1:-pilot}"
