# Trajectory-Agreement Signum

这个仓库比较标准 Signum 和两种轨迹一致性变体。两种变体都沿 Signum 的方向更新，用历史参数位移的指数移动平均（EMA）逐坐标调节步长。调节强度 `kappa` 分别采用线性和指数衰减。

## 更新规则

Signum 和两个变体都先对梯度做 EMA，再取负符号作为更新方向。最初的 Idea 2 公式从当前梯度直接取负符号。

```text
u_t = beta * u_(t-1) + (1 - beta) * g_t
r_t = -sign(u_t)
gain_t = 1 + kappa_t * (sign(m_t) * r_t)
x_(t+1) = (1 - lr_t * weight_decay) * x_t + lr_t * gain_t * r_t
m_(t+1) = gamma * m_t + (1 - gamma) * (x_(t+1) - x_t)
```

当前方向和历史位移同号时，步长乘以 `1 + kappa_t`。反号时乘以 `1 - kappa_t`，符号乘积为零时乘以 `1`。两个变体使用相同的更新式，基础学习率也按同一套日程调整。

| 实验名 | `kappa` 调度 |
| --- | --- |
| `signum` | `kappa=0`，使用标准 Signum 更新 |
| `agreement_linear` | 按训练进度线性递减，默认从 0.5 降到 0 |
| `agreement_exp` | 按平移归一化的指数曲线递减，默认从 0.5 降到 0，速率参数为 5 |

优化器源码包含 `kappa_at()` 和 `AgreementSignum`。训练脚本每步计算 `kappa_t`，再传给优化器。[优化器](optimizers.py) · [训练脚本](train.py)

## 复现实验

在带 CUDA PyTorch 的 Linux 或 AutoDL 环境中，进入仓库根目录运行。

```bash
bash reproduce.sh
```

命令依次安装依赖、准备数据、跑 100 步试运行、执行九组对照并生成图表。中断后，用同一条命令从已有检查点继续。脚本会跳过已完成的实验。

| 设置 | 2000 步对照实验 |
| --- | --- |
| 数据 | WikiText-103 raw 的训练集和验证集，GPT-2 BPE，训练最多 100M token，验证最多 1M token |
| 模型 | 约 40M 参数，9 层，8 个注意力头，隐藏维度 416 |
| 更新预算 | 每组 2,000 步，序列长度 512，微批大小 8，梯度累积 8 次 |
| 种子 | 101 |
| 峰值学习率 | `1e-5`、`3e-5`、`1e-4`，每档比较三种方法 |
| 学习率日程 | 100 步预热，之后余弦衰减至峰值的 10% |
| 优化器参数 | 梯度动量 0.9，位移 EMA 系数 0.99，权重衰减 0，梯度裁剪阈值 1.0 |
| 验证 | 每 100 步评估一次，抽取 20 个微批 |

数据准备脚本下载 WikiText-103 raw 的固定快照 `b08601e04326c79dfdd32d625aee71d232d685c3`，并把版本、token 数和文件 SHA-256 写入 `data/wikitext103/meta.json`。数据许可见上游页面。[WikiText-103 数据快照](https://huggingface.co/datasets/Salesforce/wikitext/tree/b08601e04326c79dfdd32d625aee71d232d685c3/wikitext-103-raw-v1)

训练输出在 `runs/pilot/`。其中 `protocol.json` 记录实验组合、数据元信息和训练代码哈希。每组有独立的 `config.json` 和 `metrics.csv`。用 `summary.csv` 比较同一学习率下的最终验证损失，用 `validation_loss_0_end.png` 查看训练曲线。安装脚本将 Python 包版本写入 `installed_versions.txt`，将 Python、PyTorch、CUDA 和 GPU 信息写入 `runtime.json`。

历史验证损失图来自原演示文稿，每个设置跑了一个种子。历史逐步指标和运行环境未归档到本仓库。[历史验证损失图](results/pilot-validation-loss.png)

逐步运行、自定义数据和断点恢复命令见 [原始 AutoDL 说明](README_先看这里.md)。

## CPU 检查

装好 CPU 版 PyTorch 后，可运行单元测试和使用合成 token 的小规模训练。

```bash
python -m pip install -r requirements-cpu.txt
python tests.py
python test_pipeline.py
```

小规模训练覆盖三种优化器，以及断点恢复、汇总和绘图。[测试记录](TEST_REPORT.md)

## 许可

本仓库采用 [Apache License 2.0](LICENSE)。
